# react-cursor-calendar

Activity calendar for **public Cursor profiles** (`cursor.com/@handle`).

Live API + docs: [cursor-profile.stredan.sk](https://cursor-profile.stredan.sk)

```bash
npm i react-cursor-calendar
```

```tsx
import { CursorCalendar } from "react-cursor-calendar";
import "react-cursor-calendar/tooltips.css";

<CursorCalendar handle="dadoeodo" />
```

Pass a public handle, get a heatmap. Data comes from the public profile page — Cursor does not publish a JSON API for this.

## Variants

| `variant` | What you get |
|---|---|
| `heatmap` (default) | Year heatmap + streak stats |
| `dashboard` | Heatmap, stats, 30-day token/agent charts, top models |
| `tokens` | 30-day token bars |
| `agents` | Local vs cloud agents |
| `models` | Top model usage |

```tsx
<CursorCalendar handle="dadoeodo" variant="dashboard" theme="dashboard" />
```

Themes: `cursor` (default, public-profile orange), `dashboard` (mint green), `heat`.

## Server-side (no extra round trip)

```ts
import { fetchCursorProfile } from "react-cursor-calendar/server";

const profile = await fetchCursorProfile("dadoeodo");
```

Then pass it in:

```tsx
<CursorCalendar handle="dadoeodo" data={profile} variant="heatmap" />
```

Server-side SVG (no React):

```ts
import { fetchCursorProfile, renderHeatmapSvg } from "react-cursor-calendar/server";

const profile = await fetchCursorProfile("dadoeodo");
const svg = renderHeatmapSvg(profile);
```

## Hosted API

```
GET https://cursor-profile.stredan.sk/v1/:handle
GET https://cursor-profile.stredan.sk/v1/:handle.svg
GET https://cursor-profile.stredan.sk/v1/:handle.png
```

CORS is open. Cached for an hour.

```html
<img src="https://cursor-profile.stredan.sk/v1/dadoeodo.svg" alt="Cursor activity" />
```

JSON is the parsed public profile. SVG/PNG is the orange year heatmap (tokens, same data).

```json
{
  "handle": "dadoeodo",
  "stats": { "longestStreak": 27, "currentStreak": 21 },
  "activityCounts": [{ "date": "2026-08-29", "count": 123 }]
}
```

Client components that don’t pass `data` fetch this endpoint (override with `apiBase`).

The profile must be **public** at [cursor.com/@yourhandle](https://cursor.com/help/account-and-billing/profiles).

## How it works

1. `GET https://cursor.com/@handle` with Next.js RSC headers
2. Parse the embedded profile object (`activityCounts`, streaks, models, …)
3. Map daily counts onto intensity levels 0–4
4. Render the year heatmap

This is unofficial. If Cursor changes the public profile payload, the parser breaks — open an issue.

## License

MIT
